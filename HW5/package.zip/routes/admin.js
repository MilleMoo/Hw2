const express = require('express');
const router = express.Router();
const path = require('path')
const rootDir = require('../util/path');
const product = [];


// router.get('/add-product', (req, res, next) => {
//     console.log("Add Product Page");
//     res.send(`<form action="/product" method="POST">
//              <input type="text" name="title">
//              <button type="submit">Add Product</button>
//              </form>`)
// });

router.get("/add-product", (req, res, next) => {
    res.render("add-product", {pageTitle: "Add Product"})
});   

router.post("/error", (req, res, next) => {
    console.log(req.body);
    res.redirect("/error");
});   

router.post('/add-product', (req, res, next)=> {
    console.log(req.body);
    res.redirect("/");
});

exports.router = router;
exports.product = product;